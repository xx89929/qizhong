# 用于 React

如果需要将 wangEditor 用于 React 中，可参见如下示例

- 下载源码 `git clone git@github.com:wangfupeng1988/wangEditor.git`
- 进入 React 示例目录 `cd wangEditor/example/demo/in-react/`，查看`src/App.js`即可
- 也可以运行`npm install && npm start`查看在 React 中的效果（`http://localhost:3000/`）
